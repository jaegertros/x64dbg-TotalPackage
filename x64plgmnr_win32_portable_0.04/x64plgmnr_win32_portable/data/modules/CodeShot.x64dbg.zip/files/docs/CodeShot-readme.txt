;=====================================================================================
;
; CodeShot-readme.txt
;
; v1.0.0.0 - Last updated: 28/08/2016
; 
;-------------------------------------------------------------------------------------


About
-----

CodeShot Plugin (x86) For x64dbg (32bit plugin)
by fearless - www.LetTheLight.in

Created with the x64dbg Plugin SDK For x86 Assembler
https://github.com/mrfearless/x64dbg-Plugin-SDK-For-x86-Assembler


Overview
--------

A plugin to capture the x64dbg screen to an image file


Features
--------

- Supports png, jpeg and bmp file formats
- Option to include address and/or datetime in filename
- Option to save filename to seperate folder based on module name
- Optional toolbar with dropdown menu to make it easier to take codeshots
- Hotkeys for taking codeshot image in specific formats
- Shutter sound when taking codeshot


Notes
-----

- 28/08/2016 First release
